"""
SHL Assessment Catalog Scraper
Scrapes all Individual Test Solutions from https://www.shl.com/solutions/products/product-catalog/
"""

import requests
from bs4 import BeautifulSoup
import json
import time
import re
import os

BASE_URL = "https://www.shl.com"
CATALOG_URL = "https://www.shl.com/solutions/products/product-catalog/"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}


def get_catalog_pages():
    """Fetch all pages of the Individual Test Solutions catalog."""
    assessments = []
    page = 1

    while True:
        # The SHL catalog uses pagination with 'start' parameter
        params = {
            "type": "1",  # 1 = Individual Test Solutions (not pre-packaged)
            "start": (page - 1) * 12,
        }
        print(f"Fetching page {page} (start={params['start']})...")

        try:
            resp = requests.get(CATALOG_URL, headers=HEADERS, params=params, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            print(f"Error fetching page {page}: {e}")
            break

        soup = BeautifulSoup(resp.text, "html.parser")

        # Find assessment cards/rows
        items = soup.select("tr[data-course-id], .product-catalogue__item, [class*='catalogue']")
        
        # Try table rows approach
        table_rows = soup.select("table tbody tr")
        if table_rows:
            for row in table_rows:
                cells = row.find_all("td")
                if len(cells) >= 1:
                    link = row.find("a")
                    if link and link.get("href"):
                        url = link["href"]
                        if not url.startswith("http"):
                            url = BASE_URL + url
                        name = link.get_text(strip=True)
                        
                        # Extract test types (letters in colored boxes)
                        test_types = []
                        type_spans = row.select("[class*='type'], span[class]")
                        for span in type_spans:
                            txt = span.get_text(strip=True)
                            if len(txt) == 1 and txt.upper() in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                                test_types.append(txt.upper())
                        
                        # Duration
                        duration = None
                        for cell in cells:
                            text = cell.get_text(strip=True)
                            match = re.search(r'(\d+)\s*min', text, re.IGNORECASE)
                            if match:
                                duration = int(match.group(1))
                                break
                        
                        # Remote/Adaptive
                        remote = "No"
                        adaptive = "No"
                        row_text = row.get_text(" ", strip=True).lower()
                        if "yes" in row_text:
                            # Check specific columns
                            for i, cell in enumerate(cells):
                                cell_text = cell.get_text(strip=True).lower()
                                if cell_text == "yes":
                                    if i == len(cells) - 2:
                                        remote = "Yes"
                                    elif i == len(cells) - 1:
                                        adaptive = "Yes"

                        if name and url and "product-catalog" in url:
                            assessments.append({
                                "name": name,
                                "url": url,
                                "test_types": test_types,
                                "duration": duration,
                                "remote_support": remote,
                                "adaptive_support": adaptive,
                                "description": "",
                            })

        # Check for next page
        next_btn = soup.select_one("a[rel='next'], .pagination__next, [class*='next']")
        if not next_btn:
            # Try checking if we got results
            if not table_rows or len(assessments) == 0 and page == 1:
                print("No table rows found, trying alternative selectors...")
                # Try finding product links directly
                product_links = soup.select("a[href*='product-catalog/view']")
                for link in product_links:
                    url = link["href"]
                    if not url.startswith("http"):
                        url = BASE_URL + url
                    name = link.get_text(strip=True)
                    if name:
                        assessments.append({
                            "name": name,
                            "url": url,
                            "test_types": [],
                            "duration": None,
                            "remote_support": "No",
                            "adaptive_support": "No",
                            "description": "",
                        })
            break

        page += 1
        time.sleep(1)  # Be polite

    return assessments


def get_all_assessments_paginated():
    """Scrape using pagination with &start= parameter."""
    assessments = []
    start = 0
    page_size = 12

    while True:
        url = f"{CATALOG_URL}?type=1&start={start}"
        print(f"Scraping: {url}")

        try:
            resp = requests.get(url, headers=HEADERS, timeout=15)
            resp.raise_for_status()
        except requests.RequestException as e:
            print(f"Request failed: {e}")
            break

        soup = BeautifulSoup(resp.text, "html.parser")
        
        # Look for the table with assessments
        rows = soup.select("table.custom-table tbody tr, tbody tr")
        if not rows:
            rows = soup.select("tr")
        
        found_on_page = 0
        for row in rows:
            link = row.find("a", href=re.compile(r'product-catalog/view'))
            if not link:
                continue
            
            href = link.get("href", "")
            if not href.startswith("http"):
                href = BASE_URL + href
            
            name = link.get_text(strip=True)
            cells = row.find_all("td")
            
            # Parse test type badges
            test_types = []
            for span in row.select("span.product-catalogue__list-item, [class*='type-badge'], span"):
                t = span.get_text(strip=True)
                if len(t) == 1 and t in "ABCDEFGKPS":
                    test_types.append(t)
            
            # Duration from cells
            duration = None
            remote = "No"
            adaptive = "No"
            
            for cell in cells:
                cell_text = cell.get_text(strip=True)
                m = re.search(r'(\d+)', cell_text)
                if m and duration is None and "min" in cell_text.lower():
                    duration = int(m.group(1))
                if cell_text.lower() == "yes":
                    # Determine which yes it is by position
                    idx = cells.index(cell)
                    if idx >= len(cells) - 2:
                        if idx == len(cells) - 2:
                            remote = "Yes"
                        else:
                            adaptive = "Yes"

            if name and href:
                entry = {
                    "name": name,
                    "url": href,
                    "test_types": list(set(test_types)),
                    "duration": duration,
                    "remote_support": remote,
                    "adaptive_support": adaptive,
                    "description": "",
                }
                # Avoid duplicates
                if not any(a["url"] == href for a in assessments):
                    assessments.append(entry)
                    found_on_page += 1
        
        print(f"  Found {found_on_page} new assessments. Total: {len(assessments)}")
        
        if found_on_page == 0:
            print("No new items found, stopping pagination.")
            break
        
        # Check if there's a next page link
        has_next = bool(soup.select_one("li.pagination__item--next a, a[aria-label='Next']"))
        if not has_next and found_on_page < page_size:
            break
            
        start += page_size
        time.sleep(0.5)

    return assessments


def enrich_assessment(assessment):
    """Fetch individual assessment page for full description."""
    url = assessment["url"]
    try:
        resp = requests.get(url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")
        
        # Get description
        desc_el = soup.select_one(
            ".product-catalogue-detail__description, "
            "[class*='description'], "
            "article p, "
            ".content p"
        )
        if desc_el:
            assessment["description"] = desc_el.get_text(" ", strip=True)[:500]
        
        # Get test types if not already found
        if not assessment["test_types"]:
            badges = soup.select("[class*='type-badge'], .badge, span[class*='type']")
            for b in badges:
                t = b.get_text(strip=True)
                if len(t) == 1 and t in "ABCDEFGKPS":
                    assessment["test_types"].append(t)
        
        # Duration
        if not assessment["duration"]:
            text = soup.get_text()
            m = re.search(r'(\d+)\s*minutes?', text, re.IGNORECASE)
            if m:
                assessment["duration"] = int(m.group(1))

        # Remote / adaptive
        text = soup.get_text().lower()
        if "remote" in text and "yes" in text:
            assessment["remote_support"] = "Yes"
        if "adaptive" in text and "yes" in text:
            assessment["adaptive_support"] = "Yes"
            
    except Exception as e:
        print(f"  Could not enrich {url}: {e}")
    
    return assessment


def scrape_all(enrich=True, output_path="data/shl_assessments.json"):
    """Main scrape function."""
    print("Starting SHL catalog scrape...")
    assessments = get_all_assessments_paginated()
    
    if len(assessments) < 10:
        print("Too few results, trying fallback method...")
        assessments = get_catalog_pages()
    
    print(f"\nScraped {len(assessments)} assessments total.")
    
    if enrich:
        print("\nEnriching with individual page data...")
        for i, a in enumerate(assessments):
            print(f"  [{i+1}/{len(assessments)}] {a['name'][:50]}")
            assessments[i] = enrich_assessment(a)
            time.sleep(0.3)
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(assessments, f, indent=2)
    
    print(f"\nSaved {len(assessments)} assessments to {output_path}")
    return assessments


if __name__ == "__main__":
    scrape_all(enrich=True, output_path="data/shl_assessments.json")
