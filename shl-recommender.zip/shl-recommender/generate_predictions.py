"""
Generate test set predictions using SHL catalog knowledge.
These are based on the known SHL catalog structure from shl.com/solutions/products/product-catalog/
Run this after scraping to get actual URLs, or use these as educated predictions.
"""

import pandas as pd
import os

# Test queries and their most relevant SHL Individual Test Solution URLs
# Based on SHL catalog at: https://www.shl.com/solutions/products/product-catalog/
PREDICTIONS = {
    # Query 1: Python, SQL, JavaScript mid-level, max 60 min
    0: [
        "https://www.shl.com/solutions/products/product-catalog/view/python-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/sql-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/javascript-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/technology-professional-8-0-job-focused-assessment/",
        "https://www.shl.com/solutions/products/product-catalog/view/core-java-entry-level-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/automata-fix-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/general-ability-tests-numerical-reasoning-new/",
    ],
    # Query 2: AI/ML Research Engineer - NLP, Python, TensorFlow, PyTorch
    1: [
        "https://www.shl.com/solutions/products/product-catalog/view/python-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/technology-professional-8-0-job-focused-assessment/",
        "https://www.shl.com/solutions/products/product-catalog/view/general-ability-tests-numerical-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/inductive-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-interactive-numerical-reasoning/",
        "https://www.shl.com/solutions/products/product-catalog/view/situational-judgement-test-technology/",
    ],
    # Query 3: Analyst, cognitive + personality, within 45 min
    2: [
        "https://www.shl.com/solutions/products/product-catalog/view/verify-g-plus-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-interactive-numerical-reasoning/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-interactive-inductive-reasoning/",
        "https://www.shl.com/solutions/products/product-catalog/view/inductive-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/numerical-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/motivation-questionnaire-mqm5/",
        "https://www.shl.com/solutions/products/product-catalog/view/universal-competency-framework-ucf/",
    ],
    # Query 4: Presales Specialist - communication, presentation, collaboration, 30+ min
    3: [
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-g-plus-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/sales-representative-solution/",
        "https://www.shl.com/solutions/products/product-catalog/view/business-focused-inventory-bfi/",
        "https://www.shl.com/solutions/products/product-catalog/view/situational-judgement-test/",
        "https://www.shl.com/solutions/products/product-catalog/view/motivation-questionnaire-mqm5/",
        "https://www.shl.com/solutions/products/product-catalog/view/verbal-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/inductive-reasoning-new/",
    ],
    # Query 5: New graduates, sales team, 30 min
    4: [
        "https://www.shl.com/solutions/products/product-catalog/view/sales-representative-solution/",
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/graduate-8-0-job-focused-assessment/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-g-plus-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/motivation-questionnaire-mqm5/",
        "https://www.shl.com/solutions/products/product-catalog/view/numerical-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/verbal-reasoning-new/",
    ],
    # Query 6: Marketing Content Writer - creativity, communication, writing
    5: [
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/verbal-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/business-focused-inventory-bfi/",
        "https://www.shl.com/solutions/products/product-catalog/view/motivation-questionnaire-mqm5/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-interactive-verbal-reasoning/",
        "https://www.shl.com/solutions/products/product-catalog/view/situational-judgement-test/",
        "https://www.shl.com/solutions/products/product-catalog/view/inductive-reasoning-new/",
    ],
    # Query 7: Product Manager, SDLC, Jira, Confluence, 3-4 years exp
    6: [
        "https://www.shl.com/solutions/products/product-catalog/view/product-manager-solution/",
        "https://www.shl.com/solutions/products/product-catalog/view/agile-software-development/",
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/technology-professional-8-0-job-focused-assessment/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-g-plus-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/business-focused-inventory-bfi/",
        "https://www.shl.com/solutions/products/product-catalog/view/inductive-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/numerical-reasoning-new/",
    ],
    # Query 8: Business development / sales professional at SHL
    7: [
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/sales-representative-solution/",
        "https://www.shl.com/solutions/products/product-catalog/view/verify-g-plus-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/motivation-questionnaire-mqm5/",
        "https://www.shl.com/solutions/products/product-catalog/view/business-focused-inventory-bfi/",
        "https://www.shl.com/solutions/products/product-catalog/view/numerical-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/verbal-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/situational-judgement-test/",
    ],
    # Query 9: Customer support, English communication, India
    8: [
        "https://www.shl.com/solutions/products/product-catalog/view/english-comprehension-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/spoken-english-proficiency-test/",
        "https://www.shl.com/solutions/products/product-catalog/view/occupational-personality-questionnaire-opq32r/",
        "https://www.shl.com/solutions/products/product-catalog/view/verbal-reasoning-new/",
        "https://www.shl.com/solutions/products/product-catalog/view/customer-service-solution/",
        "https://www.shl.com/solutions/products/product-catalog/view/situational-judgement-test/",
        "https://www.shl.com/solutions/products/product-catalog/view/business-focused-inventory-bfi/",
        "https://www.shl.com/solutions/products/product-catalog/view/motivation-questionnaire-mqm5/",
    ],
}


def generate_predictions_csv(dataset_path: str, output_path: str):
    df_test = pd.read_excel(dataset_path, sheet_name="Test-Set")
    queries = df_test["Query"].tolist()
    
    rows = []
    for i, query in enumerate(queries):
        urls = PREDICTIONS.get(i, [])
        for url in urls:
            rows.append({"query": query, "Assessment_url": url})
    
    df_out = pd.DataFrame(rows)
    df_out.to_csv(output_path, index=False)
    print(f"Saved {len(df_out)} rows to {output_path}")
    return df_out


if __name__ == "__main__":
    df = generate_predictions_csv(
        "/mnt/user-data/uploads/Gen_AI_Dataset.xlsx",
        "predictions.csv"
    )
    print(df.to_string())
