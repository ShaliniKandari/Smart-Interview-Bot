import { useState, useRef } from "react";

const API_BASE = process.env.REACT_APP_API_URL || "http://localhost:8000";

const TEST_TYPE_MAP = {
  A: { label: "Ability & Aptitude", color: "#3B82F6" },
  B: { label: "Biodata & SJT", color: "#8B5CF6" },
  C: { label: "Competencies", color: "#10B981" },
  D: { label: "Development & 360", color: "#F59E0B" },
  E: { label: "Assessment Exercises", color: "#EF4444" },
  K: { label: "Knowledge & Skills", color: "#06B6D4" },
  P: { label: "Personality & Behavior", color: "#EC4899" },
  S: { label: "Simulations", color: "#84CC16" },
};

const SAMPLE_QUERIES = [
  "I am hiring for Java developers who can also collaborate effectively with my business teams.",
  "Looking to hire mid-level professionals who are proficient in Python, SQL and JavaScript. Max 60 minutes.",
  "I am hiring for an analyst. Screen using cognitive and personality tests, within 45 mins.",
  "I want to hire Customer support executives expert in English communication.",
];

function TypeBadge({ type }) {
  const info = TEST_TYPE_MAP[type] || { label: type, color: "#6B7280" };
  return (
    <span
      title={info.label}
      style={{
        background: info.color + "22",
        color: info.color,
        border: `1px solid ${info.color}44`,
        borderRadius: "4px",
        padding: "2px 8px",
        fontSize: "11px",
        fontWeight: "700",
        letterSpacing: "0.05em",
        fontFamily: "monospace",
      }}
    >
      {type}
    </span>
  );
}

function AssessmentCard({ assessment, index }) {
  return (
    <div
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: "12px",
        padding: "20px 24px",
        display: "flex",
        flexDirection: "column",
        gap: "10px",
        animation: `fadeSlideIn 0.4s ease both`,
        animationDelay: `${index * 60}ms`,
        transition: "border-color 0.2s, background 0.2s",
        cursor: "default",
      }}
      onMouseEnter={e => {
        e.currentTarget.style.background = "rgba(255,255,255,0.06)";
        e.currentTarget.style.borderColor = "rgba(99,179,237,0.3)";
      }}
      onMouseLeave={e => {
        e.currentTarget.style.background = "rgba(255,255,255,0.03)";
        e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "12px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px", flex: 1 }}>
          <span style={{
            background: "rgba(99,179,237,0.15)",
            color: "#63B3ED",
            borderRadius: "8px",
            width: "32px",
            height: "32px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: "700",
            fontSize: "13px",
            flexShrink: 0,
          }}>
            {index + 1}
          </span>
          <div>
            <a
              href={assessment.url}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                color: "#E2E8F0",
                textDecoration: "none",
                fontWeight: "600",
                fontSize: "15px",
                lineHeight: "1.4",
                display: "block",
              }}
              onMouseEnter={e => (e.target.style.color = "#63B3ED")}
              onMouseLeave={e => (e.target.style.color = "#E2E8F0")}
            >
              {assessment.name}
            </a>
            <a
              href={assessment.url}
              target="_blank"
              rel="noopener noreferrer"
              style={{ color: "#4A90D9", fontSize: "12px", textDecoration: "none", opacity: 0.8 }}
            >
              {assessment.url}
            </a>
          </div>
        </div>
      </div>

      {assessment.description && (
        <p style={{ color: "#94A3B8", fontSize: "13px", margin: 0, lineHeight: "1.6" }}>
          {assessment.description.slice(0, 200)}{assessment.description.length > 200 ? "…" : ""}
        </p>
      )}

      <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", alignItems: "center" }}>
        {(assessment.test_type || []).map(t => <TypeBadge key={t} type={t} />)}
        {assessment.duration && (
          <span style={{
            background: "rgba(16,185,129,0.1)",
            color: "#10B981",
            border: "1px solid rgba(16,185,129,0.2)",
            borderRadius: "4px",
            padding: "2px 8px",
            fontSize: "11px",
            fontWeight: "600",
          }}>
            ⏱ {assessment.duration} min
          </span>
        )}
        <span style={{
          background: assessment.remote_support === "Yes" ? "rgba(99,179,237,0.1)" : "rgba(100,116,139,0.1)",
          color: assessment.remote_support === "Yes" ? "#63B3ED" : "#64748B",
          border: `1px solid ${assessment.remote_support === "Yes" ? "rgba(99,179,237,0.2)" : "rgba(100,116,139,0.2)"}`,
          borderRadius: "4px",
          padding: "2px 8px",
          fontSize: "11px",
          fontWeight: "600",
        }}>
          Remote: {assessment.remote_support || "N/A"}
        </span>
        <span style={{
          background: assessment.adaptive_support === "Yes" ? "rgba(139,92,246,0.1)" : "rgba(100,116,139,0.1)",
          color: assessment.adaptive_support === "Yes" ? "#A78BFA" : "#64748B",
          border: `1px solid ${assessment.adaptive_support === "Yes" ? "rgba(139,92,246,0.2)" : "rgba(100,116,139,0.2)"}`,
          borderRadius: "4px",
          padding: "2px 8px",
          fontSize: "11px",
          fontWeight: "600",
        }}>
          Adaptive: {assessment.adaptive_support || "N/A"}
        </span>
      </div>
    </div>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const textareaRef = useRef(null);

  const handleRecommend = async (q) => {
    const queryToUse = (q || query).trim();
    if (!queryToUse) return;
    setLoading(true);
    setError(null);
    setResults(null);

    try {
      const res = await fetch(`${API_BASE}/recommend`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: queryToUse }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Request failed");
      }
      const data = await res.json();
      setResults(data.recommended_assessments || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSample = (q) => {
    setQuery(q);
    handleRecommend(q);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0F1E",
      color: "#E2E8F0",
      fontFamily: "'DM Sans', 'Helvetica Neue', sans-serif",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap');
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.5; } }
        textarea:focus { outline: none; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #0A0F1E; }
        ::-webkit-scrollbar-thumb { background: #1E293B; border-radius: 3px; }
      `}</style>

      {/* Header */}
      <header style={{
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "20px 40px",
        display: "flex",
        alignItems: "center",
        gap: "16px",
        backdropFilter: "blur(10px)",
        position: "sticky",
        top: 0,
        zIndex: 100,
        background: "rgba(10,15,30,0.9)",
      }}>
        <div style={{
          width: "36px",
          height: "36px",
          background: "linear-gradient(135deg, #3B82F6, #8B5CF6)",
          borderRadius: "10px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: "800",
          fontSize: "16px",
        }}>S</div>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: "800", fontSize: "17px", letterSpacing: "-0.02em" }}>
            SHL Assessment Recommender
          </div>
          <div style={{ fontSize: "11px", color: "#64748B", letterSpacing: "0.08em" }}>
            AI-POWERED · RAG PIPELINE · 377+ ASSESSMENTS
          </div>
        </div>
      </header>

      <main style={{ maxWidth: "860px", margin: "0 auto", padding: "48px 24px" }}>

        {/* Hero */}
        <div style={{ textAlign: "center", marginBottom: "48px", animation: "fadeSlideIn 0.5s ease both" }}>
          <h1 style={{
            fontFamily: "'Syne', sans-serif",
            fontSize: "clamp(28px, 5vw, 48px)",
            fontWeight: "800",
            letterSpacing: "-0.03em",
            margin: "0 0 16px",
            background: "linear-gradient(135deg, #E2E8F0 0%, #63B3ED 50%, #A78BFA 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            lineHeight: 1.15,
          }}>
            Find the Right Assessment
            <br />for Every Role
          </h1>
          <p style={{ color: "#64748B", fontSize: "16px", margin: 0 }}>
            Paste a job description, URL, or natural language query to get AI-curated assessment recommendations.
          </p>
        </div>

        {/* Input Card */}
        <div style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: "16px",
          padding: "24px",
          marginBottom: "32px",
          animation: "fadeSlideIn 0.5s ease 0.1s both",
        }}>
          <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#64748B", letterSpacing: "0.08em", marginBottom: "10px" }}>
            JOB DESCRIPTION / QUERY / URL
          </label>
          <textarea
            ref={textareaRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="e.g. I am hiring Java developers who can collaborate effectively with business teams, within 40 minutes..."
            rows={5}
            style={{
              width: "100%",
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "10px",
              padding: "14px 16px",
              color: "#E2E8F0",
              fontSize: "14px",
              lineHeight: "1.6",
              resize: "vertical",
              boxSizing: "border-box",
              fontFamily: "inherit",
              transition: "border-color 0.2s",
            }}
            onFocus={e => (e.target.style.borderColor = "rgba(99,179,237,0.4)")}
            onBlur={e => (e.target.style.borderColor = "rgba(255,255,255,0.1)")}
            onKeyDown={e => {
              if (e.key === "Enter" && e.metaKey) handleRecommend();
            }}
          />

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "12px" }}>
            <span style={{ color: "#475569", fontSize: "12px" }}>⌘ + Enter to submit</span>
            <button
              onClick={() => handleRecommend()}
              disabled={loading || !query.trim()}
              style={{
                background: loading || !query.trim()
                  ? "rgba(99,179,237,0.2)"
                  : "linear-gradient(135deg, #3B82F6, #6366F1)",
                color: loading || !query.trim() ? "#64748B" : "#fff",
                border: "none",
                borderRadius: "10px",
                padding: "12px 28px",
                fontSize: "14px",
                fontWeight: "600",
                cursor: loading || !query.trim() ? "not-allowed" : "pointer",
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              {loading ? (
                <>
                  <span style={{ display: "inline-block", width: "14px", height: "14px", border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 0.7s linear infinite" }} />
                  Analyzing...
                </>
              ) : (
                <>⚡ Recommend Assessments</>
              )}
            </button>
          </div>
        </div>

        {/* Sample Queries */}
        <div style={{ marginBottom: "40px", animation: "fadeSlideIn 0.5s ease 0.15s both" }}>
          <p style={{ fontSize: "12px", color: "#475569", letterSpacing: "0.06em", fontWeight: "600", marginBottom: "10px" }}>
            TRY A SAMPLE QUERY:
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
            {SAMPLE_QUERIES.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSample(q)}
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "8px",
                  padding: "8px 14px",
                  color: "#94A3B8",
                  fontSize: "12px",
                  cursor: "pointer",
                  textAlign: "left",
                  maxWidth: "260px",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  transition: "all 0.15s",
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.background = "rgba(99,179,237,0.08)";
                  e.currentTarget.style.color = "#63B3ED";
                  e.currentTarget.style.borderColor = "rgba(99,179,237,0.2)";
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.background = "rgba(255,255,255,0.04)";
                  e.currentTarget.style.color = "#94A3B8";
                  e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
                }}
              >
                {q.slice(0, 55)}…
              </button>
            ))}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div style={{
            background: "rgba(239,68,68,0.1)",
            border: "1px solid rgba(239,68,68,0.2)",
            borderRadius: "10px",
            padding: "14px 18px",
            color: "#FCA5A5",
            marginBottom: "24px",
            fontSize: "14px",
          }}>
            ⚠ {error}
          </div>
        )}

        {/* Results */}
        {results !== null && (
          <div>
            <div style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "20px",
              animation: "fadeSlideIn 0.4s ease both",
            }}>
              <div>
                <h2 style={{ margin: 0, fontFamily: "'Syne', sans-serif", fontWeight: "700", fontSize: "20px" }}>
                  Recommended Assessments
                </h2>
                <p style={{ margin: "4px 0 0", color: "#64748B", fontSize: "13px" }}>
                  {results.length} assessment{results.length !== 1 ? "s" : ""} matched your requirements
                </p>
              </div>
              <span style={{
                background: "rgba(16,185,129,0.1)",
                color: "#10B981",
                border: "1px solid rgba(16,185,129,0.2)",
                borderRadius: "8px",
                padding: "6px 14px",
                fontSize: "13px",
                fontWeight: "600",
              }}>
                {results.length} / 10
              </span>
            </div>

            {results.length === 0 ? (
              <div style={{ textAlign: "center", color: "#475569", padding: "48px", fontSize: "15px" }}>
                No assessments found. Try a different query.
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {results.map((a, i) => (
                  <AssessmentCard key={i} assessment={a} index={i} />
                ))}
              </div>
            )}

            {/* Legend */}
            <div style={{
              marginTop: "40px",
              background: "rgba(255,255,255,0.02)",
              border: "1px solid rgba(255,255,255,0.06)",
              borderRadius: "12px",
              padding: "20px",
            }}>
              <p style={{ margin: "0 0 12px", fontSize: "11px", fontWeight: "700", color: "#475569", letterSpacing: "0.08em" }}>
                TEST TYPE LEGEND
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                {Object.entries(TEST_TYPE_MAP).map(([k, v]) => (
                  <div key={k} style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", color: "#64748B" }}>
                    <TypeBadge type={k} />
                    <span>{v.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
