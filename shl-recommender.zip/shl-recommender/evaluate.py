"""
Evaluation Script
Computes Mean Recall@K on the labeled train set.
"""

import json
import sys
import os
import pandas as pd
from typing import List, Dict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
from recommender import SHLRecommender


def recall_at_k(predicted_urls: List[str], relevant_urls: List[str], k: int = 10) -> float:
    """Compute Recall@K for a single query."""
    if not relevant_urls:
        return 0.0
    predicted_top_k = predicted_urls[:k]
    
    # Normalize URLs for comparison
    def norm(url: str) -> str:
        return url.rstrip("/").lower().replace("http://", "https://")
    
    pred_set = {norm(u) for u in predicted_top_k}
    rel_set = {norm(u) for u in relevant_urls}
    
    hits = len(pred_set & rel_set)
    return hits / len(rel_set)


def mean_recall_at_k(results: List[Dict], k: int = 10) -> float:
    """Compute Mean Recall@K across all queries."""
    if not results:
        return 0.0
    return sum(r["recall@k"] for r in results) / len(results)


def evaluate(
    dataset_path: str = "Gen_AI_Dataset.xlsx",
    assessments_path: str = "backend/data/shl_assessments.json",
    index_path: str = "backend/data/tfidf_index.json",
    k: int = 10,
    api_key: str = None,
):
    """Run evaluation on train set."""
    
    # Load train data
    df = pd.read_excel(dataset_path, sheet_name="Train-Set")
    
    # Group by query
    query_groups = df.groupby("Query")["Assessment_url"].apply(list).reset_index()
    print(f"Evaluating on {len(query_groups)} queries...")
    
    # Init recommender
    rec = SHLRecommender(
        assessments_path=assessments_path,
        index_path=index_path,
        anthropic_api_key=api_key or os.environ.get("ANTHROPIC_API_KEY", ""),
    )
    
    results = []
    for _, row in query_groups.iterrows():
        query = row["Query"]
        relevant = row["Assessment_url"]
        
        print(f"\nQuery: {query[:80]}...")
        print(f"Relevant assessments: {len(relevant)}")
        
        recommendations = rec.recommend(query, n_results=k)
        predicted_urls = [r["url"] for r in recommendations]
        
        recall = recall_at_k(predicted_urls, relevant, k=k)
        results.append({
            "query": query[:80],
            "n_relevant": len(relevant),
            "n_predicted": len(predicted_urls),
            "recall@k": recall,
            "predicted_urls": predicted_urls,
            "relevant_urls": relevant,
        })
        print(f"Recall@{k}: {recall:.3f}")
        print(f"Predictions: {predicted_urls[:3]}")
    
    mean_recall = mean_recall_at_k(results, k=k)
    print(f"\n{'='*50}")
    print(f"Mean Recall@{k}: {mean_recall:.4f}")
    print(f"{'='*50}")
    
    # Save detailed results
    with open("evaluation_results.json", "w") as f:
        json.dump({"mean_recall@k": mean_recall, "k": k, "results": results}, f, indent=2)
    
    return mean_recall, results


def generate_test_predictions(
    dataset_path: str = "Gen_AI_Dataset.xlsx",
    output_csv: str = "predictions.csv",
    assessments_path: str = "backend/data/shl_assessments.json",
    index_path: str = "backend/data/tfidf_index.json",
    api_key: str = None,
):
    """Generate predictions on the test set and save as CSV."""
    df_test = pd.read_excel(dataset_path, sheet_name="Test-Set")
    queries = df_test["Query"].tolist()
    
    print(f"Generating predictions for {len(queries)} test queries...")
    
    rec = SHLRecommender(
        assessments_path=assessments_path,
        index_path=index_path,
        anthropic_api_key=api_key or os.environ.get("ANTHROPIC_API_KEY", ""),
    )
    
    rows = []
    for i, query in enumerate(queries):
        print(f"\n[{i+1}/{len(queries)}] {str(query)[:80]}...")
        recommendations = rec.recommend(str(query), n_results=10)
        for r in recommendations:
            rows.append({"query": query, "Assessment_url": r["url"]})
    
    result_df = pd.DataFrame(rows)
    result_df.to_csv(output_csv, index=False)
    print(f"\nPredictions saved to {output_csv}")
    print(result_df.head(20))
    return result_df


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["eval", "predict"], default="eval")
    parser.add_argument("--dataset", default="/mnt/user-data/uploads/Gen_AI_Dataset.xlsx")
    parser.add_argument("--assessments", default="backend/data/shl_assessments.json")
    parser.add_argument("--index", default="backend/data/tfidf_index.json")
    parser.add_argument("--output", default="predictions.csv")
    parser.add_argument("--api-key", default=None)
    args = parser.parse_args()
    
    if args.mode == "eval":
        evaluate(args.dataset, args.assessments, args.index, api_key=args.api_key)
    else:
        generate_test_predictions(args.dataset, args.output, args.assessments, args.index, api_key=args.api_key)
