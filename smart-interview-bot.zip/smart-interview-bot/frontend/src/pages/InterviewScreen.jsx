import React, { useState, useRef, useEffect } from 'react';
import { useInterviewStore } from '../store';
import { evaluateAnswer, fetchQuestion } from '../api';
import { useSpeech } from '../hooks/useSpeech';
import ScoreCard from '../components/ScoreCard';

const DOMAIN_LABELS = { dsa: 'DSA & Algorithms', hr: 'HR & Behavioral', system: 'System Design', frontend: 'Frontend Dev' };

export default function InterviewScreen() {
  const {
    domain, messages, qIndex, totalQ, loading,
    setLoading, addMessage, attachScore, addScore,
    incrementQ, addPreviousQuestion, previousQuestions,
    setScreen,
  } = useInterviewStore();

  const [answer, setAnswer] = useState('');
  const chatRef = useRef(null);

  const { listening, supported, start, stop } = useSpeech((text) => {
    setAnswer((prev) => prev ? prev + ' ' + text : text);
  });

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, loading]);

  async function handleSubmit() {
    const text = answer.trim();
    if (!text || loading) return;

    const lastBotMsg = [...messages].reverse().find(m => m.role === 'bot');
    if (!lastBotMsg) return;

    setAnswer('');
    addMessage({ role: 'user', content: text });
    setLoading(true);

    try {
      const result = await evaluateAnswer({
        domain,
        question: lastBotMsg.content,
        answer: text,
        questionNumber: qIndex + 1,
        totalQuestions: totalQ,
      });

      attachScore({ confidence: result.confidence, keywords: result.keywords, clarity: result.clarity, feedback: result.feedback });
      addScore({ confidence: result.confidence, keywords: result.keywords, clarity: result.clarity });
      incrementQ();

      if (qIndex + 1 >= totalQ || !result.nextQuestion) {
        setLoading(false);
        setTimeout(() => setScreen('results'), 800);
      } else {
        addMessage({ role: 'bot', content: result.nextQuestion });
        addPreviousQuestion(result.nextQuestion);
        setLoading(false);
      }
    } catch (e) {
      addMessage({ role: 'bot', content: 'Error evaluating answer. Please check your backend.' });
      setLoading(false);
    }
  }

  const progress = Math.min(qIndex, totalQ);

  return (
    <div className="max-w-2xl mx-auto py-6 px-4 flex flex-col h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-lg">🤖</div>
          <div>
            <h2 className="font-semibold text-sm">{DOMAIN_LABELS[domain]}</h2>
            <p className="text-xs text-gray-400">Question {Math.min(qIndex + 1, totalQ)} of {totalQ}</p>
          </div>
        </div>
        <span className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
          {progress}/{totalQ} done
        </span>
      </div>

      {/* Progress */}
      <div className="flex gap-1 mb-4">
        {Array.from({ length: totalQ }).map((_, i) => (
          <div
            key={i}
            className={`flex-1 h-1 rounded-full transition-all ${
              i < qIndex ? 'bg-green-500' : i === qIndex ? 'bg-blue-400' : 'bg-gray-200'
            }`}
          />
        ))}
      </div>

      {/* Chat */}
      <div ref={chatRef} className="flex-1 overflow-y-auto flex flex-col gap-4 mb-4">
        {messages.map((msg, i) => (
          <div key={i}>
            <div className={`flex gap-2 items-start ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-sm flex-shrink-0">
                {msg.role === 'bot' ? '🤖' : '👤'}
              </div>
              <div
                className={`max-w-prose rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === 'bot'
                    ? 'bg-white border border-gray-200 text-gray-800'
                    : 'bg-blue-50 border border-blue-100 text-blue-900'
                }`}
              >
                {msg.content}
              </div>
            </div>
            {msg.scoreData && <ScoreCard data={msg.scoreData} />}
          </div>
        ))}

        {loading && (
          <div className="flex gap-2 items-start">
            <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-sm">🤖</div>
            <div className="bg-white border border-gray-200 rounded-2xl px-4 py-3">
              <div className="flex gap-1 items-center h-4">
                {[0, 1, 2].map((n) => (
                  <span
                    key={n}
                    className="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce"
                    style={{ animationDelay: `${n * 0.15}s` }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex gap-2 items-end">
        {supported && (
          <button
            onClick={listening ? stop : start}
            className={`p-3 rounded-xl border text-sm transition ${
              listening ? 'bg-red-50 border-red-300 text-red-600' : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'
            }`}
            title={listening ? 'Stop recording' : 'Start voice input'}
          >
            {listening ? '⏹' : '🎤'}
          </button>
        )}
        <textarea
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(); } }}
          placeholder="Type your answer... (Enter to send, Shift+Enter for newline)"
          disabled={loading}
          rows={2}
          className="flex-1 resize-none rounded-xl border border-gray-200 px-4 py-3 text-sm focus:outline-none focus:border-gray-400 disabled:opacity-50 bg-white"
        />
        <button
          onClick={handleSubmit}
          disabled={!answer.trim() || loading}
          className="px-5 py-3 rounded-xl border border-gray-300 bg-white text-sm font-medium hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Send ↗
        </button>
      </div>
    </div>
  );
}
