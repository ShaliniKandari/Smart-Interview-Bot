import React from 'react';
import { useInterviewStore } from '../store';
import { fetchQuestion } from '../api';

const DOMAINS = [
  { id: 'dsa',      label: 'DSA & Algorithms',  icon: '🧮', desc: 'Arrays, trees, graphs, DP' },
  { id: 'hr',       label: 'HR & Behavioral',   icon: '🤝', desc: 'STAR method, soft skills' },
  { id: 'system',   label: 'System Design',     icon: '🏗️', desc: 'Scalability, architecture' },
  { id: 'frontend', label: 'Frontend Dev',      icon: '💻', desc: 'React, JS, CSS, browser APIs' },
];

export default function SetupScreen() {
  const { domain, setDomain, setLoading, loading, addMessage, addPreviousQuestion, setScreen, totalQ } = useInterviewStore();

  async function handleStart() {
    if (!domain) return;
    setLoading(true);
    setScreen('interview');
    try {
      const question = await fetchQuestion({ domain, questionNumber: 1, totalQuestions: totalQ, previousQuestions: [] });
      addMessage({ role: 'bot', content: question });
      addPreviousQuestion(question);
    } catch (e) {
      addMessage({ role: 'bot', content: 'Failed to load question. Check your API key and backend.' });
    }
    setLoading(false);
  }

  return (
    <div className="max-w-lg mx-auto py-12 px-4">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-2xl">🤖</div>
        <div>
          <h1 className="text-xl font-semibold">Smart Interview Bot</h1>
          <p className="text-sm text-gray-500">AI-powered practice with real-time feedback</p>
        </div>
      </div>

      <p className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3">Choose your domain</p>
      <div className="grid grid-cols-2 gap-3 mb-6">
        {DOMAINS.map((d) => (
          <button
            key={d.id}
            onClick={() => setDomain(d.id)}
            className={`p-4 rounded-xl border text-left transition-all ${
              domain === d.id
                ? 'border-blue-400 bg-blue-50 text-blue-800'
                : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50'
            }`}
          >
            <div className="text-xl mb-1">{d.icon}</div>
            <div className="font-medium text-sm">{d.label}</div>
            <div className="text-xs text-gray-400 mt-0.5">{d.desc}</div>
          </button>
        ))}
      </div>

      <button
        onClick={handleStart}
        disabled={!domain || loading}
        className="w-full py-3 rounded-xl border border-gray-300 bg-white font-medium text-sm hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition"
      >
        {loading ? 'Loading...' : 'Start Interview →'}
      </button>
    </div>
  );
}
