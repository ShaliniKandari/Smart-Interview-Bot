import React from 'react';
import { useInterviewStore } from '../store';

const DOMAIN_LABELS = { dsa: 'DSA & Algorithms', hr: 'HR & Behavioral', system: 'System Design', frontend: 'Frontend Dev' };

function avg(scores, key) {
  if (!scores.length) return 0;
  return Math.round(scores.reduce((a, b) => a + b[key], 0) / scores.length);
}

const bars = [
  { key: 'confidence', label: 'Avg Confidence', color: 'bg-blue-500' },
  { key: 'keywords',   label: 'Avg Keywords',   color: 'bg-green-500' },
  { key: 'clarity',    label: 'Avg Clarity',    color: 'bg-amber-500' },
];

export default function ResultsScreen() {
  const { scores, domain, reset } = useInterviewStore();

  const avgConf = avg(scores, 'confidence');
  const avgKeys = avg(scores, 'keywords');
  const avgClar = avg(scores, 'clarity');
  const overall = Math.round((avgConf + avgKeys + avgClar) / 3);

  const grade =
    overall >= 85 ? { label: 'Excellent', color: 'text-green-600' } :
    overall >= 70 ? { label: 'Good',      color: 'text-blue-600' } :
    overall >= 50 ? { label: 'Fair',      color: 'text-amber-600' } :
                    { label: 'Needs Work', color: 'text-red-500' };

  return (
    <div className="max-w-lg mx-auto py-12 px-4">
      <div className="bg-white border border-gray-200 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-2xl">🏁</div>
          <div>
            <h2 className="font-semibold">Interview Complete</h2>
            <p className="text-sm text-gray-500">{DOMAIN_LABELS[domain]}</p>
          </div>
        </div>

        <div className="mb-6">
          <div className="text-5xl font-semibold">{overall}<span className="text-xl text-gray-400">/100</span></div>
          <div className={`text-sm font-medium mt-1 ${grade.color}`}>{grade.label}</div>
        </div>

        <div>
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">Score Breakdown</p>
          {bars.map(({ key, label, color }) => {
            const val = key === 'confidence' ? avgConf : key === 'keywords' ? avgKeys : avgClar;
            return (
              <div key={key} className="flex items-center gap-3 mb-3">
                <span className="w-32 text-sm text-gray-500">{label}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-2">
                  <div className={`${color} h-2 rounded-full`} style={{ width: `${val}%` }} />
                </div>
                <span className="w-8 text-right text-sm font-medium">{val}</span>
              </div>
            );
          })}
        </div>

        <div className="mt-4 p-3 bg-gray-50 rounded-xl">
          <p className="text-xs text-gray-500 mb-2 font-medium">Per-question scores</p>
          <div className="flex gap-2 flex-wrap">
            {scores.map((s, i) => {
              const q = Math.round((s.confidence + s.keywords + s.clarity) / 3);
              return (
                <div key={i} className="text-center">
                  <div className="text-xs text-gray-400 mb-1">Q{i + 1}</div>
                  <div className={`text-sm font-semibold ${q >= 70 ? 'text-green-600' : q >= 50 ? 'text-amber-600' : 'text-red-500'}`}>{q}</div>
                </div>
              );
            })}
          </div>
        </div>

        <button
          onClick={reset}
          className="w-full mt-5 py-3 rounded-xl border border-gray-200 text-sm hover:bg-gray-50 transition"
        >
          Start a new interview
        </button>
      </div>
    </div>
  );
}
