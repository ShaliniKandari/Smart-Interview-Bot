import { create } from 'zustand';

export const useInterviewStore = create((set, get) => ({
  // State
  screen: 'setup',       // 'setup' | 'interview' | 'results'
  domain: null,
  messages: [],          // { role: 'bot'|'user', content, scoreData? }
  qIndex: 0,
  totalQ: 5,
  scores: [],
  loading: false,
  previousQuestions: [],

  // Actions
  setDomain: (domain) => set({ domain }),

  setLoading: (loading) => set({ loading }),

  addMessage: (msg) => set((s) => ({ messages: [...s.messages, msg] })),

  attachScore: (scoreData) => set((s) => {
    const messages = [...s.messages];
    // attach to last bot message
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'bot' && !messages[i].scoreData) {
        messages[i] = { ...messages[i], scoreData };
        break;
      }
    }
    return { messages };
  }),

  addScore: (score) => set((s) => ({ scores: [...s.scores, score] })),

  incrementQ: () => set((s) => ({ qIndex: s.qIndex + 1 })),

  addPreviousQuestion: (q) => set((s) => ({
    previousQuestions: [...s.previousQuestions, q],
  })),

  setScreen: (screen) => set({ screen }),

  reset: () => set({
    screen: 'setup',
    domain: null,
    messages: [],
    qIndex: 0,
    scores: [],
    loading: false,
    previousQuestions: [],
  }),
}));
