import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export async function fetchQuestion({ domain, questionNumber, totalQuestions, previousQuestions }) {
  const { data } = await api.post('/question', {
    domain,
    questionNumber,
    totalQuestions,
    previousQuestions,
  });
  return data.question;
}

export async function evaluateAnswer({ domain, question, answer, questionNumber, totalQuestions }) {
  const { data } = await api.post('/evaluate', {
    domain,
    question,
    answer,
    questionNumber,
    totalQuestions,
  });
  return data;
}
