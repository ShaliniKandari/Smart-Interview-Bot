import React from 'react';
import { useInterviewStore } from './store';
import SetupScreen from './pages/SetupScreen';
import InterviewScreen from './pages/InterviewScreen';
import ResultsScreen from './pages/ResultsScreen';

export default function App() {
  const screen = useInterviewStore((s) => s.screen);

  return (
    <div className="min-h-screen bg-gray-50">
      {screen === 'setup'     && <SetupScreen />}
      {screen === 'interview' && <InterviewScreen />}
      {screen === 'results'   && <ResultsScreen />}
    </div>
  );
}
