import React from 'react';

const bars = [
  { key: 'confidence', label: 'Confidence', color: 'bg-blue-500' },
  { key: 'keywords',   label: 'Keywords',   color: 'bg-green-500' },
  { key: 'clarity',    label: 'Clarity',    color: 'bg-amber-500' },
];

export default function ScoreCard({ data }) {
  if (!data) return null;
  return (
    <div className="mt-2 ml-10 bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm">
      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">Answer Evaluation</p>
      {bars.map(({ key, label, color }) => (
        <div key={key} className="flex items-center gap-3 mb-2">
          <span className="w-20 text-gray-500 text-xs">{label}</span>
          <div className="flex-1 bg-gray-200 rounded-full h-1.5">
            <div
              className={`${color} h-1.5 rounded-full transition-all duration-700`}
              style={{ width: `${data[key]}%` }}
            />
          </div>
          <span className="w-8 text-right font-medium text-gray-700">{data[key]}</span>
        </div>
      ))}
      {data.feedback && (
        <p className="mt-3 text-gray-600 leading-relaxed">{data.feedback}</p>
      )}
    </div>
  );
}
